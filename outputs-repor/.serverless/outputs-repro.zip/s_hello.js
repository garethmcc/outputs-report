
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'garethsneworgtest',
  applicationName: 'outputstest',
  appUid: 'Q3Ym7wpcKmw2HSKWQq',
  orgUid: '469ffeac-5cc2-4239-89ac-d8eb8dcf9db4',
  deploymentUid: 'c43344aa-0d9c-4351-ac90-4fa688bee8f2',
  serviceName: 'outputs-repro',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'outputs-repro-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}